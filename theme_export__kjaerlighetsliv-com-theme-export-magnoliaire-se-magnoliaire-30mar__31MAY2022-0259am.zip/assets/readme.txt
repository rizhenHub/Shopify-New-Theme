Theme Name: Debutify
Theme Author: Debutify
Theme Version: 4.9.0
Theme URI: https://debutify.com
Theme Documentation: https://help.debutify.com
Terms of use: https://debutify.com/terms-of-use
Terms of sales: https://debutify.com/terms-of-sales
Privacy policy: https://debutify.com/privacy-policy
Report a bug: https://feedback.debutify.com/b/bug-reports/
Request a new feature: https://feedback.debutify.com/b/feature-requests/

Copyright Debutify Inc. All rights reserved.
